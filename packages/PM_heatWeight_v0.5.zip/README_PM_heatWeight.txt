version 0.5

SETUP:
------
Step 1: Copy the script files,
      /scripts/PM_heatWeight.py
      /scripts/AttachWeights.exe
      /scripts/Pinocchio.dll
   
   to the your scripts folder: it's exact location varies depending on your os.

On Windows XP:
   C:\Documents and Settings\[USER]\My Documents\maya\[VERSION]\scripts
On Vista:
   C:\Users\[USER]\Documents\maya\[VERSION]\scripts

Step 2: Copy In/Add to your userSetup.py
   If the above folder did not contain a file called 'userSetup.py' (NOTE- the
   ending is .py, NOT .mel!!!) copy in the provided one - otherwise, open it
   and add it's contents to the end of the existing userSetup.py
   (NOTE: On windows, use notepad or wordpad, NOT microsoft word!) 

Step 3: Create a shelf icon
   With maya closed, copy:
      /prefs/icons/heatWeight.bmp
   to:
      /maya/[VERSION]/prefs/icons/
   Also, copy:
      /prefs/shelves/shelf_heatWeight.mel
   to:
      /maya/[VERSION]/prefs/shelves/
   (When you start maya, you may drag the shelf button to another shelf with
   the middle mouse button, and then delete the 'heatWeight' shelf, if so
   desired.)
   
USAGE:
------
Select the root of the skeleton you wish to weight to, then the mesh you wish
to weight, then click the shelf button; wait a few moments for the command-
line utility to finish, and you're done. 

copyright 2009 Paul Molodowitch